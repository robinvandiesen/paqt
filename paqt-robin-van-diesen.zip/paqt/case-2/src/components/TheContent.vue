<template>
  <div class="box">
    Content
  </div>
</template>

<style scoped>
.box {
  height: 500px;
}
</style>
