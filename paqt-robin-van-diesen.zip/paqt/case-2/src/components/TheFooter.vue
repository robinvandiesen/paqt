<template>
  <div class="box">
    Footer
  </div>
</template>
