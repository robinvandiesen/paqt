<template>
  <header>
    <div class="box">
      Header
    </div>
  </header>
</template>
