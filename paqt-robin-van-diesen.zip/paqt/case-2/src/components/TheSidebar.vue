<template>
  <div class="box">
    Sidebar
  </div>
</template>

<style scoped>
.box {
  height: 500px;
}
</style>